# Browser-Based-Intrusion-Detection-System
Simple Browser based Intrusion Detection System that works on Admin-User based approach
